
````markdown
# A - Bluesee's XOR

## Background

Bluesee the bear, the beloved mascot of FoSE (Faculty of Science and Engineering), UNNC, is organizing a special activity for the Computer Psycho Union (CPU). As part of the welcome event, Bluesee has prepared a series of coding challenges for students.

The first challenge is a warm-up problem to test everyone's understanding of basic bitwise operations. Bluesee believes that mastering XOR operations is essential for competitive programming!

## Problem Description

You are given two integers $A$ and $B$. Your task is to compute $A \oplus B$, where $\oplus$ denotes the bitwise `XOR` operation.

The bitwise `XOR` operation compares each bit of its operands. For each bit position, if the bits are different, the result has a $1$ in that position; otherwise, it has a $0$.

Help Bluesee verify the answers to make sure everyone gets started on the right foot!

## Input Format

The first line contains an integer $T$ ($1 \le T \le 10^{5}$), the number of test cases.

Each of the next $T$ lines contains two integers $A$ and $B$ ($0 \le A, B \le 10^{18}$).

## Output Format

For each test case, output a single line containing the value of $A \oplus B$.

## Sample Input

```
3
5 3
10 10
123456789 987654321
```


## Sample Output

```
6
0
1032168868
```


## Sample Explanation

**Test Case 1:** $5 \oplus 3$

- $5$ in binary: $101_2$
- $3$ in binary: $011_2$
- XOR result: $110_2 = 6$

**Test Case 2:** $10 \oplus 10$

- $10$ in binary: $1010_2$
- $10$ in binary: $1010_2$
- XOR result: $0000_2 = 0$

## Constraints

<div align=center>

| Testpoint | $T$ | $A, B$ |
| :---: | :---: | :---: |
| Sample | $3$ | As shown |
| $1$–$5$ | $T \le 10$ | $A,B \le 10^{3}$ |
| $6$–$10$ | $T \le 100$ | $A,B \le 10^{9}$ |
| $11$–$20$ | $T \le 10^{5}$ | $A,B \le 10^{18}$ |

</div>

<div class="break-page"/>

***

````

