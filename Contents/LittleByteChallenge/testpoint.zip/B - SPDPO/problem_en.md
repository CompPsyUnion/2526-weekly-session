
````markdown
# B - $\mathfrak{SBDPO} $

## Problem Description

Freshmen need to earn $50$ SPDPO credits in their first academic year, most of which can be obtained by participating in activities organized by various organizations (such as CPU). For the busy student Bruce, he has $t$ hours of free time in a week. During this week, there are $n$ activities with start time $a_i$, end time $b_i$, and credit $c_i$. For activities with conflicting time, Bruce can only participate in one of them. Find the maximum number of credits Bruce can earn in this week.

## Input Format

The first line contains two integers $n$ and $t$ ($1 \le n < 100$, $0 < t < 24$), representing the total number of activities and Bruce's free time (in hours).

The next $n$ lines each contain three integers $a_i$, $b_i$, $c_i$ ($0 < a_i < b_i < 24$, $0 < c_i < 10$), representing the start time, end time, and credits of the $i$-th activity.

## Output Format

Output a single integer representing the maximum number of credits Bruce can earn in a week without time conflicts.

## Sample Input

```
4 10
1 3 5
2 5 6
4 7 3
6 9 8
```


## Sample Output

```
14
```

## Sample Explanation

Among the $4$ given activities, choose two activities with non-conflicting time intervals:
1. Activity $2$: start time $2$, end time $5$, earning $6$ credits
2. Activity $4$: start time $6$, end time $9$, earning $8$ credits

Total credits: $6 + 8 = 14$. Both activities are within Bruce's $10$-hour free time and provide the maximum total credits achievable.

## Constraints

- $0 < t < 24$
- $0 < n < 100$
- $0 < a_i < b_i < 24$
- $0 < c_i < 10$

<div align=center>

| Test Case | $n$ | $t$ |
| :---: | :---: | :---: |
| Sample | $n = 4$ | $t = 10$ |
| $1$–$3$ | $n \le 5$ | $10 < t < 20$ |
| $4$–$6$ | $10 \le n \le 20$ | $15 \le t \le 22$ |
| $7$–$10$ | $30 \le n \le 50$ | $18 \le t \le 22$ |
| $11$–$15$ | $60 \le n \le 80$ | $20 \le t \le 22$ |
| $16$–$20$ | $80 \le n < 100$ | $22 \le t < 24$ |

</div>

<div class="break-page"/>

***

````

