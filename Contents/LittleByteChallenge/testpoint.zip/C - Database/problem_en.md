
````markdown
# C - Database

## Background

Baicen LIU, the president of UNNC's Computer Psycho Union (CPU), assigned Robert the task of analyzing freshmen enrollment data for the new academic year. The database contains important information like student IDs, admission scores, and contact numbers.

However, disaster struck! When Robert attempted to export the data, a critical system error occurred. Instead of neat columns and rows, the entire database got jumbled into a single corrupted string. Student IDs merged with phone numbers, admission scores mixed with dormitory room numbers, and everything became an incomprehensible mess of digits, letters, and special characters.

"This is terrible!" Robert exclaimed, staring at the garbled output on his screen.

Your task is to help Robert extract the longest consecutive sequence of digits from the corrupted data string.

## Problem Description

Given a string $S$ consisting of lowercase letters, uppercase letters, digits, and special characters, find the **longest consecutive sequence of digits** and output it as an integer.

If there are multiple sequences of the same maximum length, output the **largest** one numerically.

If there are no digits in the string, output $-1$.

## Input Format

The first line contains an integer $T$ ($1 \le T \le 100$), the number of test cases.

Each of the next $T$ lines contains a string $S$ ($1 \le |S| \le 10^{5}$), representing the corrupted data.

$S$ consists of:
- Lowercase letters ($a$-$z$)
- Uppercase letters ($A$-$Z$)
- Digits ($0$-$9$)
- Special characters (space, `.`, `-`, `@`, `#`, etc.)

## Output Format

For each test case, output a single integer representing the longest consecutive sequence of digits.

If there are multiple sequences with the same maximum length, output the numerically largest one.

If no digits exist in the string, output $-1$.

## Sample Input

```
5
abc123xyz456def
StudentID:20241001,Score:98,Phone:13812345678
Hello@World!
Room305-Phone:1234567-Grade:95
a1b2c3d4e5f6g7h8i9j0
```


## Sample Output

```
456
13812345678
-1
1234567
9
```

## Sample Explanation

**Test Case 1:** `abc123xyz456def`
- Digit sequences: `123`, `456`
- Maximum length: $3$
- Both have length $3$, so output the larger: `456`

**Test Case 2:** `StudentID:20241001,Score:98,Phone:13812345678`
- Digit sequences: $20241001$ (8 digits), $98$ (2 digits), $13812345678$ (11 digits)
- Maximum length: $11$
- Output: $13812345678$ (the phone number!)

**Test Case 3:** `Hello@World!`
- No digits found
- Output: $-1$

**Test Case 4:** `Room305-Phone:1234567-Grade:95`
- Digit sequences: $305$ (3 digits), $1234567$ (7 digits), $95$ (2 digits)
- Maximum length: $7$
- Output: $1234567$

**Test Case 5:** `a1b2c3d4e5f6g7h8i9j0$
- Digit sequences: $1,2,3,4,5,6,7,8,9,0$
- Maximum length: $1$
- All have length $1$, largest is: $9$

## Constraints

<div align=center>

| Test Cases | $T$ | $\lvert S \rvert$ | Number Length |
| :---: | :---: | :---: | :---: |
| Sample | $5$ | Various | $\le 20$ digits |
| $1$–$3$ | $T \le 5$ | $\lvert S \rvert \le 50$ | $\le 10$ digits |
| $4$–$6$ | $T \le 10$ | $\lvert S \rvert \le 100$ | $\le 15$ digits |
| $7$–$9$ | $T \le 20$ | $\lvert S \rvert \le 500$ | $\le 18$ digits |
| $10$–$12$ | $T \le 50$ | $\lvert S \rvert \le 1000$ | $\le 30$ digits |
| $13$–$15$ | $T \le 80$ | $\lvert S \rvert \le 5000$ | $\le 50$ digits |
| $16$–$17$ | $T = 100$ | $\lvert S \rvert \le 10^{4}$ | $\le 60$ digits |
| $18$–$19$ | $T = 100$ | $\lvert S \rvert \le 5\times 10^{4}$ | |
| $20$ | $T = 100$ | $\lvert S \rvert = 10^{5}$ | $\le 100$ digits |

</div>

<div class="break-page"/>

***

````

