
````markdown
# D - Investigation

## Background

Baicen was woken up by an anonymous call late in the night calling him to go to Xiaoshiguang.
He is now exploring Xiaoshiguang in complete darkness, trying to figure out what has happened. 

You need to **simulate his behavior** and determine the conclusion he eventually reaches based on his action sequence.

## Problem Description

Given a string $S$, each character represents one of Baicen's actions.  
Different actions trigger different psychological states, and when certain conditions are met, Baicen draws a conclusion.

### Action Characters

<div align=center>

| Character | Action Description |
| :---: | :---: |
| `s` | Search the room |
| `l` | Turn on the light |
| `d` | Check the desk |
| `c` | Call Robert |
| `x` | Call Zhou |
| `t` | Check the time |
| `q` | Say to himself "Have I traveled through time?" |
| `w` | Recall the previous scene |
| `h` | Shout "Where are you!" |
| `z` | Stare blankly (end action) |

</div>

### Rules and Priority

<div align=center>

| Priority | Trigger Condition | Output Conclusion |
| :---: | :---: | :---: |
| $1$ | Before `z`, no `l`, `s`, `d` appeared | Baicen stands dazed, doing nothing |
| $2$ | Consecutive `cc` or `xx` | The other party hung up, Baicen sinks into thought |
| $3$ | Consecutive `t -> c` or `t -> x` followed by `q` | Baicen suspects he has traveled through time |
| $4$ | Consecutive `l -> d -> w` | Baicen realizes the desk has been cleared |
| $5$ | Consecutive `s -> h`, and no `c` or `x` appeared before | Baicen shouts in the dark, no one responds |
| $6$ | No `l` appears anywhere, current char is `s` or `d` | In total darkness, Baicen sees nothing |
| $7$ | Consecutive `t -> c` | Robert is awakened, anger $+1$ |
| $8$ | Consecutive `t -> x` | Zhou is awakened, but he doesn't dare to be angry |
| $9$ | Consecutive `t -> w -> q`, and no `c` or `x` appeared before `t` | Baicen feels he is in the Trisolaris world |
| $10$ | Before current position, at least one of $l$, $s$, $t$ appeared, and none of $d$, $q$, $w$, $h$ appeared | Baicen feels everything is normal, keeps idling |
| $11$ | None of the above | Baicen sinks into endless contemplation |

</div>

## Input Format

The first line contains an integer $T$ ($1 \le T \le 10^{4}$).  

The next $T$ lines each contain a string $S$ ($1 \le |S| \le 10^{5}$).  

$S$ only contains $\{l,s,d,c,x,t,q,w,h,z\}$.

## Output Format

For each input, output a single line with the corresponding conclusion (in English).  

Do not output extra blank lines or spaces. All punctuation is English, no periods.

## Sample Input

```
3
tcq
ldw
ssshh
```


## Sample Output

```
Baicen suspects he has traveled through time
Baicen realizes the desk has been cleared
Baicen shouts in the dark, no one responds
```

## Sample Explanation

1. `tcq` triggers Rule $3$ (`t -> c -> q`)  
2. `ldw` triggers Rule $4$ (`l -> d -> w`)  
3. `ssshh` triggers Rule $5$ (`s -> h`)  

## Constraints

<div align=center>

| Test Case | $T$ | $\lvert S \rvert$ | Special Constraints |
| :---: | :---: | :---: | :---: |
| Sample | $T = 3$ | As given | |
| $1$–$4$ | $T = 1$ | $\lvert S \rvert < 100$ | No conflict triggered |
| $5$–$8$ | $T = 1$ | $\lvert S \rvert < 100$ | |
| $9$–$13$ | $T < 50$ | $\lvert S \rvert < 10^{4}$ | No conflict triggered |
| $14$–$18$ | $T < 50$ | $\lvert S \rvert < 10^{4}$ | |
| $19$ | $T = 50$ | $\lvert S \rvert = 10^{4}$ | |
| $20$ | $T = 1$ | $\lvert S \rvert < 10^{4}$ | |

</div>

<div class="break-page"/>

***

````

