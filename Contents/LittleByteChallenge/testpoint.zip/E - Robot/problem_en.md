# Problem ? Legend_book

## Background

There is a legendary book in a corner of the UNNC library that can be obtained by answering the robot judge's questions. The judge only asks multiplication problems. After computing the product, the judge removes every even decimal digit from the result; if nothing remains, the judge expects `0`.

## Problem Description

Given two non-negative integers $A$ and $B$, compute the product $P=A\times B$. Remove every even digit (i.e. digits in the set $\{0,2,4,6,8\}$) from the decimal representation of $P$. Output the remaining digits as an integer (preserving their original order). If no digits remain after deletion, output $0$.

## Input Format

The input consists of multiple test cases. The first line contains an integer $N$ — the number of test cases. Each of the following $N$ lines contains two non-negative integers $A$ and $B$, separated by a single space.

## Output Format

For each test case print a single line with the integer obtained by deleting all even digits from the decimal representation of $A\times B$. If the resulting sequence is empty, print `0`.

## Sample Input

```
6
1 9
35 2
35 121
57 1999
256 987543
```

## Sample Output

```
9
0
7
35
113943
511
```

## Explanation (brief)

- Case 1: $1\times 9=9$ → keep $9$.  
- Case 2: $14\times 16=224$ → all digits even → output $0$.  
- Case 3: $35\times 2=70$ → delete $0$ → output $7$.





## Constraints

<div align=center>

| Test Case | $N$ | $\lvert A\rvert,\lvert B\rvert$ |
|------|----|-----------|
| Sample | $N = 6$ | $1 \le \lvert A\rvert,\lvert B\rvert \le 3$ |
| $1$–$10$ | $1 \le N \le 5$ | $1 \le \lvert A\rvert,\lvert B\rvert \le 100$ |
| $11$–$20$ | $1 \le N \le 10$ | $100 \le \lvert A\rvert,\lvert B\rvert \le 4000$ |

</div>