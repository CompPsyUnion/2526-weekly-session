
````markdown
# F - Around the World

## Background

After trying hard for many years, LBC has finally received a pilot license.

To celebrate the fact, he intends to buy himself an airplane and fly around the planet 3-SATurn (as you may have guessed, this is the planet on which LBC is located).

## Problem Description

Specifically, LBC plans to fly along the equator.

Unfortunately, the equator is rather long, necessitating refuels.

The flight range (on full tank) of each aircraft is known.

There are $n$ airports along the equator, and a plane can be refueled when it lands on one.

Since buying an airplane is a big decision, LBC asks your help.

He is about to present you with a list of different plane models he is considering.

Naturally, these differ in their flight range.

For each plane model, he would like to know the minimum number of landings (including the final one) he would have to make in order to complete the journey.

Note that for each airplane model, the journey may start at a different airport.

## Input Format

The first line of the standard input contains two integers $n$ and $s$ ($2\le n \le 10^{6}$, $1\le s \le 100$), separated by a single space, denoting the number of airports along the equator and the number of airplane models LBC is considering.

The second line contains $n$ positive integers $l_1,l_2,\dots,l_n$ ($\sum_{i=1}^{n} l_i \le 10^{9}$), separated by single spaces, specifying the distances between successive airports along the equator.

The number $l_i$ is the distance between the $i$-th and $(i+1)$-st (or $n$-th and $1$-st if $i=n$) in kilometers.

The third line contains $s$ integers $d_1,d_2,\dots,d_s$ ($1\le d_i \le \sum_{i=1}^{n} l_i$), separated by single spaces. The number $d_i$ is the $i$-th airplane model's flight range in kilometers, i.e., the maximum distance it can fly before landing and refueling.

## Output Format

Your program should print $s$ lines to the standard output: the $i$-th of these should contain a single integer, namely, the minimum number of flight segments (and thus also landings) necessary to fly the $i$-th airplane around the planet 3-SATurn along the equator, starting at an airport of choice, or the word `NIE` (Polish for no) if it is impossible to complete the journey with this airplane.

## Sample Input:

```
6 4
2 2 1 3 3 1
3 2 4 11
```


## Sample Output:

```
4
NIE
3
2
```

## Sample Explanation

Let the airports be labelled $A_1, A_2, \dots, A_6$ with distances
$\ell_1 = 2$, $\ell_2 = 2$, $\ell_3 = 1$, $\ell_4 = 3$, $\ell_5 = 3$, $\ell_6 = 1$ (total circumference $\sum_{i=1}^{6} \ell_i = 12$).

- For flight range $d = 3$: it is possible to complete the circle in $4$ flight segments. For example, start at $A_4$ and take flights of lengths $\ell_4=3$, $\ell_5=3$, $\ell_6+\ell_1=1+2=3$, and $\ell_2+\ell_3=2+1=3$, covering the whole equator in $4$ segments, each $\le 3$.

- For flight range $d = 2$: since some inter-airport distances equal $3$ (namely $\ell_4$ and $\ell_5$), any airplane with $d=2$ cannot traverse those single legs and thus completing the journey is impossible; output `NIE`.

- For flight range $d = 4$: the trip can be completed in $3$ segments, e.g. $\ell_1+\ell_2=2+2=4$, $\ell_3+\ell_4=1+3=4$, and $\ell_5+\ell_6=3+1=4$, so the minimal number is $3$.

- For flight range $d = 11$: the whole equator can be covered in $2$ segments, for instance $\ell_1+\ell_2+\ell_3=2+2+1=5$ and the remaining $7$ for the other segment, both $\le 11$, so the minimal number is $2$.

## Constraints

<div align=center>

| Testpoint | $n$ | $s$ | $\sum_{i=1}^{n} \ell_i$ |
| :---: | :---: | :---: | :---: |
| Sample | $n = 6$ | $s = 4$ | $\sum \ell_i = 12$ |
| $1$–$3$ | $n \le 10$ | $s \le 5$ | $\sum \ell_i \le 10^{4}$ |
| $4$–$6$ | $n \le 10^{3}$ | $s \le 10$ | $\sum \ell_i \le 10^{6}$ |
| $7$–$10$ | $n \le 10^{5}$ | $s \le 50$ | $\sum \ell_i \le 10^{8}$ |
| $11$–$20$ | $n \le 10^{6}$ | $s \le 100$ | $\sum \ell_i \le 10^{9}$ |

</div>

<div class="break-page"/>

***

````

