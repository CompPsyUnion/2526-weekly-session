
````markdown
# G - Alternating Subsequence

## Background
Little Byte Challenge is ongoing fiercely, but some people pass varying numbers of test points at different times—sometimes more, sometimes less. Therefore, the chairperson is very curious about how many problems this unstable state will last in total.

## Description
Given an integer sequence of length $n$: $a_1, a_2, \dots, a_n$. We call a subsequence (maintaining relative order, not necessarily contiguous) "alternating-difference" if the sign of consecutive differences alternates strictly between positive and negative. In other words, for a subsequence $b_1, b_2, \dots, b_k$ ($k \geq 1$), for every $i$ ($1 \leq i \leq k-2$) we have $(b_{i+1} - b_i) \cdot (b_{i+2} - b_{i+1}) < 0$. Differences cannot be zero (consecutive equal elements are not allowed in an alternating subsequence).

Your task is to find the length of the longest alternating-difference subsequence.

## Input Format
The first line contains an integer $n$ ($1 \leq n \leq 200000$), the length of the sequence.  
The second line contains $n$ integers $a_1, a_2, \dots, a_n$, where $|a_i| \leq 10^9$.

## Output Format
Print a single integer — the length of the longest alternating-difference subsequence.

## Sample Input

```
8
1 7 4 9 2 5 5 6
```


## Sample Output

```
6
```

Explanation: One longest alternating-difference subsequence is $[1,7,4,9,2,5]$ of length $6$. Note that the two consecutive $5$s in the sequence cannot both be used because their difference is $0$.

## Constraints

<div align=center>

| Testpoint | $n$ | Notes |
| :---: | :---: | :---: |
| Sample | $n = 8$ | As given |
| $1$–$3$ | $n \le 10$ | |
| $4$–$6$ | $n \le 10^{3}$ | |
| $7$–$10$ | $n \le 10^{5}$ | |
| $11$–$24$ | $n \le 2\times 10^{5}$ | Time $O(n)$ or $O(n\log n)$ |

</div>

<div class="break-page"/>

***

````

