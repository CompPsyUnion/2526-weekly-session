
<!-- Updated from root Problem Statement.md on 2025-10-24 -->
# H - Adventure

## Background

At UNNC campus, there lives a goose named **Nuomi**. Nuomi wanders around campus every day. She has a peculiar habit—she loves to peck at switches to turn on lights, seemingly fascinated by brightness.

Today, Nuomi is searching for food while also looking for her mate. Thanks to her long neck, Nuomi can stretch to reach things within a certain range around her. However, if Nuomi accidentally steps on food she hasn't seen yet, she gets startled and loses some stamina.

## Problem Description

The UNNC campus is abstracted as an $N \times M$ grid:

- Each cell may be empty, contain food, a light switch, or one of Nuomi's potential mates (Mate A / Mate B).  
- Nuomi has an initial position and initial stamina $Q$.  
- Mate A and Mate B are initially fixed at specific positions on the grid.  
- Light switches illuminate a square area of fixed size. A light at $(x,y)$ illuminates all food in $x\in[x-R,x+R],\ y\in[y-R,y+R]$. Once activated, the light remains on permanently.  
- After each move, Nuomi stretches her neck to **search** around:  
	- When at $(x,y)$, her neck length $S$ determines the search range $x\in[x-S,x+S],\ y\in[y-S,y+S]$.  
	- **Illuminated** food in the search area will be spotted and eaten by Nuomi. Mate A and Mate B can be found regardless of illumination if within the search range.  
	- If Nuomi moves to a cell containing uneaten food, she gets startled and loses $1$ stamina point, but immediately eats that food.  
- If Nuomi's stamina reaches zero or below, she collapses from exhaustion, and the output is $\text{Dead}$. 

Nuomi's movement commands include:

- `U` Walk up  
- `D` Walk down  
- `L` Walk left  
- `R` Walk

## Input Format

```

N M R S Q # Campus grid size, light radius, neck length (search radius), initial stamina
x_O y_O # Nuomi's initial position (1-based)
x_M y_M # Mate A's position
x_S y_S # Mate B's position
K # Number of light switches
x1 y1 # Light switch coordinates
...
xK yK
P # Number of food items
x1 y1 # Food coordinates
...
xP yP
T # Length of move sequence
S # Move command string of length T

```

- $N,M,R,S,Q$ are campus dimensions, light radius, Nuomi's neck length (search radius), and initial stamina  
- All coordinates are $1$-based  
- $2 \le N, M \le 5000$  
- $1 \le R,S \le \min(N, M)$  
- $0 \le K \le 500$  
- $0 \le P \le 0.2 \cdot N \cdot M$  
- $1 \le T \le 10^{5}$

## Output Format

Output Nuomi's final statistics:
```
food_count remaining_stamina Mate_A_status(0/1) Mate_B_status(0/1)

```

- **Mate A status**: $1$ if found, $0$ otherwise  
- **Mate B status**: $1$ if found, $0$ otherwise  

If stamina reaches zero or below, output:
```
Dead
```

## Sample Input

```
5 5 1 1 10
3 3
1 1
5 5
1
2 2
2
2 3
4 4
4
RDDL

```
## Sample Output
```
2 8 1 1
```

**Explanation:**

- Nuomi starts at $(3,3)$ with $10$ stamina.  
- There is one light switch at $(2,2)$, which illuminates food within radius $1$ when activated.  
- Food items are at $(2,3)$ and $(4,4)$.  
- Mate A at $(1,1)$ and Mate B at $(5,5)$.  
- Nuomi moves `$R D D L$`. During this process:  
	- Food at $(4,4)$ is eaten.  
	- Mate B is found.  
	- Stamina decreases by $1$ due to stepping on food $(4,4)$ and getting startled, resulting in $9$ remaining stamina.

## Constraints

<div align=center>

| Test Case | $T$ (moves) | $\lvert S \rvert$ (items) | Special Restrictions |
| :---: | :---: | :---: | :---: |
| Sample | $T = 4$ | $P = 2$ | As given |
| $1$–$2$ | $T \le 10$ | $P = 0$ | |
| $3$–$4$ | $T \le 10$ | $P < 500$ | Notripping,nocapture |
| $5$–$6$ | $T \le 10$ | $P < 500$ | |
| $7$–$8$ | $T \le 10$ | $P < 500$ | |
| $9$–$10$ | $T < 1000$ | $P < 5000$ | |
| $11$–$12$ | $T < 1000$ | $P < 5000$ | |
| $13$–$14$ | $T < 5000$ | $P < 20000$ | Notripping |
| $15$–$16$ | $T < 5000$ | $P < 20000$ | |
| $17$–$18$ | $T < 20000$ | $P < 50000$ | |
| $19$ | $T < 10^{5}$ | $P = 10^{5}$ | |
| $20$ | $T < 10^{5}$ | $P = 10^{5}$ | |

</div>

<div class="break-page"/>

<!-- End of generated Problem.md -->
