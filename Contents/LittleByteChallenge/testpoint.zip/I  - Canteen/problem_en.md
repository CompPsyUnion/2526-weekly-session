
````markdown
# I - Canteen

## Background

Life at the University of Nottingham Ningbo China (UNNC) involves many important decisions, and one of the most crucial is: **where to eat?**

Nuomi, the beloved campus mascot, has been observing students' dining habits and noticed that many students struggle to balance their meal budgets with their precious study time. To help students make better dining choices, Nuomi has created this optimization challenge!

## Problem Description

There are three popular canteens near the UNNC dormitory buildings:
- **Canteen A**: The Third Space (第三空间) - A modern café-style canteen popular for its comfortable atmosphere
- **Canteen B**: Canteen 3 (三食堂) - The traditional main canteen with diverse Chinese cuisine
- **Canteen C**: Small Kitchen (小灶台) - A cozy spot known for its quick service and local flavors

Each canteen has different waiting times and meal prices, reflecting real conditions on campus.

A UNNC student needs to eat at the canteens $m$ times per week ($3 \le m \le 21$). For each meal, the student must choose one canteen, and **It is not allowed to dine at the same restaurant for $m$ consecutive times.** (to maintain dietary variety and avoid long queues at peak times).

Given a total weekly budget of $q$ yuan ($10 \le q \le 200$), the student wants to minimize the total waiting time to maximize study and leisure time.

Help Nuomi calculate the minimum total waiting time that can be achieved within the budget!

## Input Format

The first line contains two integers $m$ and $q$ ($3 \le m \le 21$, $10 \le q \le 200$), representing the number of meals and the budget (in yuan).

The second line contains three integers $t_A$, $t_B$, $t_C$ ($1 \le t_i \le 30$), representing the average waiting time (in minutes) for canteens A, B, and C respectively.

The third line contains three integers $p_A$, $p_B$, $p_C$ ($8 \le p_i \le 32$), representing the average meal price (in yuan) for canteens A, B, and C respectively.

## Output Format

If a valid meal plan exists within the budget, output a single integer representing the minimum total waiting time (in minutes).

If it is impossible to complete $m$ meals within the budget $q$, output `$-1$`.

## Sample Input

```
5 50
5 10 8
8 15 12
```


## Sample Output

```
38
```

## Constraints

<div align=center>

| Test Case | $m$ | $q$ |
| :---: | :---: | :---: |
| Sample | $m = 5$ | $q = 50$ |
| $1$–$10$ | $3 \le m \le 10$ | $10 \le q \le 100$ |
| $11$–$20$ | $3 \le m \le 21$ | $10 \le q \le 200$ |

</div>

<div class="break-page"/>

***

````

