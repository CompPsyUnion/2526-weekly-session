````markdown
# J - Loyalty

## Problem Description

Baicen LIU, the president of the Computer Programming Union (CPU), wants to test everyone's loyalty by organizing all CPU members into two rows, with $n$ people in each row. These members need to be divided into $m$ rectangular groups.

CPU is a united community, and Baicen doesn't want anyone to be left out, so **every person must belong to exactly one group**.

Each group reflects the loyalty of its members to some extent. A group's **loyalty value** is defined as the sum of all its members' loyalty values. To maintain a low profile, Baicen wants to minimize the maximum loyalty value among the $m$ groups.

However, he doesn't know how to divide the members to achieve this goal. Can you help him?

## Input Format

The first line contains two integers $n$ and $m$ ($1 \le n \le 100000$, $1 \le m \le 100$), representing the number of people in each row and the number of groups.

The second line contains $n$ integers representing the loyalty values of members in the first row.

The third line contains $n$ integers representing the loyalty values of members in the second row.

All loyalty values are positive integers not exceeding $10^{9}$.

## Output Format

Output a single integer: the **minimum possible value of the maximum loyalty** among all groups in the optimal division scheme.

## Sample Input

```
3 3
1 3 2
1 3 2
```


## Sample Output

```
4
```

## Constraints

<div align=center>

| Test Cases | $n$ | $m$ |
| :---: | :---: | :---: |
| Sample | As given | |
| $1$–$3$ | $n \le 10$ | $m \le 5$ |
| $4$–$6$ | $n \le 150$ | $m \le 30$ |
| $7$–$10$ | $n \le 500$ | $m \le 50$ |
| $11$–$13$ | $n \le 500$ | $m \le 50$ |
| $14$–$16$ | $n \le 2000$ | $m \le 100$ |
| $17$–$20$ | $n \le 100000$ | $m \le 100$ |

</div>

<div class="break-page"/>

***

````
<!-- Updated from root Problem Statement.md on 2025-10-24 -->
# J - Loyalty

## Problem Description

Arrange 2×n people into m rectangular groups so every person belongs to exactly one group. Each person's loyalty value is given; a group's loyalty is the sum of its members' values. Minimize the maximum loyalty among the m groups.

## Input Format

First line: n m. Second line: loyalties of first row. Third line: loyalties of second row.

## Output Format

Minimum possible value of the maximum group loyalty.

<!-- End of generated Problem.md -->
