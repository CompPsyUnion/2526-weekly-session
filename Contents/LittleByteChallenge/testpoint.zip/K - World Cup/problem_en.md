````markdown
# K - World Cup

## Problem Description

This year, the Basketball World Cup was held in China. LBC wants to participate in some competitions. He has no preference for any team and no time limit. If he has enough money, he will participate in all the competitions. Unfortunately, he only has a limited amount of RMB, all of which can be used to buy tickets.

Considering the cost of each match, calculate the number of ways LBC can participate in a group of matches **without exceeding the budget**. If there is a competition where participants participate in one way but do not participate in another, it is considered that the two ways are different.

## Input Format

The input is read from standard input.

- The first line contains two positive integers:  
  $N$ and $M$ ($1 \leq N \leq 40$, $1 \leq M \leq 10^{18}$),  
  representing the number of matches and the total budget in RMB, respectively.

- The second line contains $N$ space-separated positive integers, each not exceeding $10^{16}$,  
  representing the cost of attending each match.

## Output Format

Output a single line containing the number of ways Bobek can attend the matches **without exceeding his budget**.  
Note: Due to the constraint on $N$, this number will be at most $2^{40}$.

## Sample Input

```
5 1000
100 500 500 1000 1000
```
## Sample Output

```
9
```
## Sample Explanation
The eight possible ways are:

- No matches attended.
- The match worth $100$.
- The first match worth $500$.
- The second match worth $500$.
- The match worth $100$ and the first match worth $500$.
- The match worth $100$ and the second match worth $500$.
- Both matches worth $500$.
- The match worth $1000$.

## Constraints

<div align=center>

| Test Cases | $N$ | $M$ |
| :---: | :---: | :---: |
| Sample | As given | |
| $1$–$3$ | $N \le 10$ | $M$ small |
| $4$–$6$ | $N \le 150$ | $M$ medium |
| $7$–$10$ | $N \le 500$ | $M$ larger |
| $11$–$13$ | $N \le 500$ | $M$ larger |
| $14$–$16$ | $N \le 2000$ | $M$ up to $10^{9}$ |
| $17$–$20$ | $N \le 40$ | $M \le 10^{18}$ |

</div>

<div class="break-page"/>

***

````
<!-- Updated from root Problem Statement.md on 2025-10-24 -->
# K - World Cup

## Problem Description

Given N matches with costs and budget M, count the number of subsets of matches whose total cost ≤ M.

## Input Format

First line: N M. Second line: N costs.

## Output Format

One integer: number of valid subsets.

<!-- End of generated Problem.md -->