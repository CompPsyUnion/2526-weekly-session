````markdown
# L - Moodle

##  Background

**October 14th — Moodle crashed.**  
All course materials were gone, slides disappeared, and quizzes refused to open.

Even worse, **UNUK went on strike.**

Senior **Sun Yidong** from the IT department has vanished into the UNNC Psychology Association,  
leaving behind a pile of mysterious folders labeled _“Emergency Patches.”_  
And you — the unluckiest first-year student in the School of Computer Science —  
have been _urgently appointed_ to take over this digital catastrophe.

Rumor has it that these patches were written by students from different years —  
chaotic in style, confusing logic, and some even _introduce new bugs while fixing the old ones._  
Your mission: use the **shortest possible time**  
to bring **Moodle** back to normal operation.


##  Problem Description

There are $n$ known bugs in the system.  
The IT department provides $m$ patches, each with its own quirks and conditions:

- A patch can only be applied when the system **contains** certain bugs ($B1_i$)  
    and **does not contain** certain others ($B2_i$).
    
- Applying patch $i$ will **fix** some bugs ($F1_i$) but may **introduce** new ones ($F2_i$).
  
- Installing patch $i$ takes $t_i$ units of time.
  

Your task is to design an algorithm that selects and arranges the patches in an order  
that completely fixes the system with the **minimum total time**.


##  Input Format

The first line contains two integers $n$ and $m$,  
representing the total number of bugs and the total number of patches.

Each of the next $m$ lines describes a patch:

- A positive integer representing the time required to install it;
  
- Followed by two strings of length $n$, separated by a space.
  

The first string represents **installation conditions**:

- `$+$` → this bug **must exist**;
  
- `$-$` → this bug **must not exist**;
  
- `$0$` → this bug **doesn’t affect** applicability.
  

The second string represents **patch effects**:

- `$-$` → this bug will be **fixed**;
  
- `$+$` → this bug will be **introduced**;
  
- `$0$` → this bug will **remain unchanged**.
  


##  Output Format

Output the minimum total time required to repair Moodle completely (no bugs left).  
If it’s impossible to fix, output `$0$`.


##  Sample Input  


```
3 3 
1 000 00- 
1 00- 0-+ 
2 0-- -++
```


##  Sample Output

```
8
```


## Constraints

<div align=center>

| Test Cases | $n$ | $m$ |
| :---: | :---: | :---: |
| Sample | As given | |
| $1$–$3$ | $n \le 10$ | $m \le 5$ |
| $4$–$6$ | $n \le 150$ | $m \le 30$ |
| $7$–$10$ | $n \le 500$ | $m \le 50$ |
| $11$–$13$ | $n \le 500$ | $m \le 50$ |
| $14$–$16$ | $n \le 2000$ | $m \le 100$ |
| $17$–$20$ | $n \le 100000$ | $m \le 100$ |

</div>

***


````
<!-- Updated from root Problem Statement.md on 2025-10-24 -->
# L - Moodle

## Background

There are n bugs and m patches. Each patch has applicability conditions (bugs that must/must not exist), effects (fix/introduction of bugs), and time cost. Find the minimal total time to reach a state with zero bugs, or output 0 if impossible.

## Input Format

First line: n m. Next m lines: time followed by two strings of length n — installation condition (+/-/0) and patch effects (-/+/0).

## Output Format

Minimum total time to fix all bugs, or 0 if impossible.

<!-- End of generated Problem.md -->
