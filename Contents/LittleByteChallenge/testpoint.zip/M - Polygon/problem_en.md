# M - Polygon

## Background

Bluesee the bear is enjoying his trip in space. Gazing down at Earth's surface he imagines chains of landmarks—mountain peaks, lighthouses, and harbors—as points on a map. Curious whether the closed shape formed by joining these landmarks in order is bulging outward everywhere (convex) or has inward dents (concave), he asks how to decide this from the coordinates alone. Please help him.

## Problem Statement

Given an integer $n$ and an ordered list of vertices $p_0,p_1,\dots,p_{n-1}$ in the plane, where $p_i=(x_i,y_i)$ and the polygon formed by joining $p_0\to p_1\to\cdots\to p_{n-1}\to p_0$ is simple, determine whether the polygon is convex. Output `true` if the polygon is convex and `false` otherwise.

Remarks. A polygon is convex iff every internal angle is at most $180^\circ$. Equivalently, for all consecutive triples of vertices the signed cross product of the two edge vectors has the same sign (ignoring zero values). Define, for indices modulo $n$,
\[
\operatorname{cross}(a,b,c)= (b_x-a_x)(c_y-a_y)-(b_y-a_y)(c_x-a_x).
\]
Let $z_i=\operatorname{cross}(p_i,p_{i+1},p_{i+2})$ for $i=0,\dots,n-1$. The polygon is convex iff all nonzero $z_i$ have the same sign.

## Input Format

The first line contains an integer $n$ ($3\le n\le 10^4$).  
Each of the next $n$ lines contains two integers $x_i$ and $y_i$ ($-10^4\le x_i,y_i\le 10^4$), the coordinates of $p_i$, given in order.

## Output Format

Print a single line containing `true` if the polygon is convex, otherwise `false`.


## Sample Input
```
4
0 0
0 5
5 5
5 0
```

## Sample Output
```
true
```

## Constraints

- The polygon is simple (no edge intersections other than adjacent edges at shared vertices).
- All input points are distinct.
- $3 \le n \le 10^4$.
- $\forall i:\ -10^4 \le x_i,y_i \le 10^4$.


<div align=center>

| Test Case | $n$ | Coordinate bounds | Special Constraints |
| :---: | :---: | :---: | :---: |
| Sample | $n = 4$ | As given | |
| $1$–$4$ | $n \le 10$ | $-10^4 \le x_i,y_i \le 10^4$ | No degenerate edges |
| $5$–$8$ | $n \le 100$ | $-10^4 \le x_i,y_i \le 10^4$ | |
| $9$–$13$ | $n \le 10^3$ | $-10^4 \le x_i,y_i \le 10^4$ |  |
| $14$–$18$ | $n \le 5\times 10^3$ | $-10^4 \le x_i,y_i \le 10^4$ | |
| $19$ | $n = 10^4$ | $-10^4 \le x_i,y_i \le 10^4$ |  |
| $20$ | $n \le 10^4$ | $-10^4 \le x_i,y_i \le 10^4$ |  |

</div>

<div class="break-page"/>

