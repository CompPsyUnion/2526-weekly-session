#include<bits/stdc++.h>
using namespace std;
const int N = 10005;
const double alpha = 0.997;
int n, x[N], y[N], w[N];
double ansx, ansy, dis;
double calc(double xx, double yy) { // 计算解对应的E值
    double res = 0;
    for (int i = 1; i <= n; ++i) {
        double dx = x[i] - xx, dy = y[i] - yy;
        res += sqrt(dx * dx + dy * dy) * w[i];
    }
    return res;
}

void simulateAnneal() {//模拟退火
    double t = 10000;
    double nxtx,nxty,delta,ndis;
    while (t > 1e-15) {
        nxtx = ansx + t * (rand() * 2 - RAND_MAX);
        nxty = ansy + t * (rand() * 2 - RAND_MAX);//生成新解
        ndis = calc(nxtx, nxty);
        delta = ndis - dis;//生成∆E
        if (delta < 0) ansx = nxtx, ansy = nxty, dis=ndis;//如果新解更优，直接替换
        else if (exp(-delta / t) > rand()) ansx = nxtx, ansy = nxty;//如果新解更劣，以一定概率替换
        t *= alpha;//降温
    }
}

signed main() {
    scanf("%d",&n);
    for (int i = 1; i <= n; ++i) {
        scanf("%d%d%d",&x[i],&y[i],&w[i]);
        ansx += x[i], ansy += y[i];
    }
    ansx /= n, ansy /= n, dis = calc(ansx, ansy);
    simulateAnneal();
    simulateAnneal();
    simulateAnneal();
    simulateAnneal();
    printf("%.3f %.3f",ansx, ansy);
    return 0;
}